from rl_pipeline.models.feature_extractors.resnet_extractor import ResnetMLP

AVAILABLE_MODELS = {
    'ResnetMLP': ResnetMLP,
    }
